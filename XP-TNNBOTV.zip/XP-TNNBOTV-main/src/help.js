const help = (prefix) => { 
	return `                 
┏━━━°❀ ❬ OWNER CIMMAND ❭ ❀°━━━┓
┃
┏❉ *${prefix}bc*
┣❉ *${prefix}block*
┣❉ *${prefix}unblock*
┃
┣━━━°❀ ❬ STICKER COMMAND ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker*
┣➥ *${prefix}tsticker*
┣➥ *${prefix}nulis*
┃
┣━━━°❀ ❬ DONASI | BESTFREND ❭ ❀°━━━⊱
┃
┣➥ *${prefix}donasi*
┣➥ *${prefix}Thanks To #Alfa📣*
┣➥ *${prefix}Support Bot XPTN*
┣➥ *${prefix}Web Api : xptnbotapi.herokuapp.com*
┃
┣━━━°❀ ❬ UPDATE COMMAND ❭ ❀°━━━⊱
┃
┣➥ *${prefix}text3d*
┣➥ *${prefix}ninjalogo*
┣➥ *${prefix}quotes*
┣➥ *${prefix}lirik*
┣➥ *${prefix}bucin*
┣➥ *${prefix}wolflogo*
┣➥ *${prefix}lionlogo*
┣➥ *${prefix}tebakgambar*
┣➥ *${prefix}caklontong*
┣➥ *${prefix}family100*
┣➥ *${prefix}game*
┣➥ *${prefix}textscreen <teks>*
┣➥ *${prefix}tahta <teks>*
┣➥ *${prefix}rtext <teks>*
┣➥ *${prefix}glitch <teks> | <teks>*
┣➥ *${prefix}party <teks>*
┣➥ *${prefix}lovemake <teks>*
┣➥ *${prefix}primbonjodoh <teks> | <teks>*
┣➥ *${prefix}artinama <nama>*
┣➥ *${prefix}ramalhp <nomor>*
┃
┣━━━━°❀🔗 ❬ COMMAND NSFW ❭ 🔗❀°━━━⊱
┃
┣➥ *${prefix}loli*
┣➥ *${prefix}waifu*
┣➥ *${prefix}randomhentai*
┣➥ *${prefix}nsfwtrap*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}nsfwneko*
┣➥ *${prefix}loli*
┃Jika Inging mengaktifkan nya ketik
┃nsfw1 kalo mau di nonaktifkan nsfw0
┣━━━°❀ ❬ COMMAND DOWNLOADER ❭ ❀°━━⊱
┃
┣➥ *ytsearch* [search yt]
┣➥ *ytmp3* [link]
┣➥ *tiktok* [link]
┃
┣━━━━°❀ ❬ GROUB ONLY ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}add* [62xxx]
┣➥ *${prefix}kick* [tag]
┣➥ *${prefix}setpp*
┣➥ *${prefix}demote* [tag]
┣➥ *${prefix}promote* [tag]
┣➥ *${prefix}setpp*
┣➥ *${prefix}group* [buka/tutup]
┣➥ *${prefix}welcome* [1/0]
┣➥ *${prefix}nsfw* [1/0]
┣➥ *${prefix}simih* [1/0]
┣➥ *${prefix}groupinfo*
┃
┣━━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}bc* 
┣➥ *${prefix}leave*
┣➥ *${prefix}clearall*
┣➥ *${prefix}setprefix*
┣➥ *${prefix}clone* [tag]
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┣➥ *${prefix}getses*
┃
┣━━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}listadmin*
┣➥ *${prefix}blocklist*
┣➥ *${prefix}simi*
┣➥ *${prefix}wait*
┣➥ *${prefix}fitnah*
┣➥ *${prefix}tiktokstalk*
┣➥ *${prefix}url2img*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ ${prefix}*Follow IG* ~_xptn~
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help